import pluginJs from '@eslint/js';
import pluginTs from '@typescript-eslint/eslint-plugin'; // Correct import
import pluginReact from 'eslint-plugin-react';
import globals from 'globals';

/** @type {import('eslint').Linter.Config[]} */
export default [
  {
    files: ['src/**/*.{js,mjs,cjs,ts,jsx,tsx}'],
    languageOptions: {
      globals: globals.browser,
    },
    plugins: {
      react: pluginReact,
    },
    settings: {
      react: {
        version: 'detect',
      },
    },
    rules: {
      'react/react-in-jsx-scope': 'off',
      'react/jsx-uses-react': 'off',
    },
    env: {
      node: true,
    },
    ignorePatterns: [
      'types/**.*',
      '**.d.ts',
      '**.d.tsx',
      'webpack',
      'webpack.**.*',
      'dist',
      'node_modules',
      'eslint.config.js',
    ],
  },
  pluginJs.configs.recommended,
  pluginTs.configs.recommended,
  pluginReact.configs.flat.recommended,
];
