import { Button, Typography } from '@mui/material';

const App = () => {
  return (
    <>
      <Typography variant="h4" gutterBottom>
        Hello, Material UI!
      </Typography>
      <Button variant="contained" color="primary">
        Click Me
      </Button>
    </>
  );
};

export default App;
